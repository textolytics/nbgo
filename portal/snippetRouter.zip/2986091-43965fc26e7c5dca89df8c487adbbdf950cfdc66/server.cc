#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <czmq.h>
#include <zmq.h>

#include <map>
#include <string>

using std::map;
using std::string;

int main() {
  map<string, string> dict;

  zctx_t *ctx = zctx_new();
  void *router = zsocket_new(ctx, ZMQ_ROUTER);
  zmsg_t *msg;
  zsocket_bind(router, "tcp://*:1111");

  while ((msg = zmsg_recv(router)) != NULL) {
    zframe_t *address = zmsg_pop(msg);
    char *op = zmsg_popstr(msg);
    char *key = zmsg_popstr(msg);
    if (!strcmp(op, "set")) {
      char *value = zmsg_popstr(msg);
      dict[key] = value;
      zmsg_pushstr(msg, "ok");
    } else if (!strcmp(op, "get")) {
      auto it = dict.find(key);
      if (it != dict.end()) {
        zmsg_pushstr(msg, "%s",  it->second.c_str());
      } else {
        zmsg_pushstr(msg, "not_found");
      }
    } else if (!strcmp(op, "delete")) {
      auto it = dict.find(key);
      if (it != dict.end()) {
        dict.erase(it);
        zmsg_pushstr(msg, "deleted");
      } else {
        zmsg_pushstr(msg, "not_found");
      }
    } else {
      zmsg_pushstr(msg, "unknown op");
    }
    zmsg_push(msg, address);
    zmsg_send(&msg, router);
  }

  zsocket_destroy(ctx, router);
  zctx_destroy(&ctx);

  return 0;
}