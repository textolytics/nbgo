./server &
CLIENT_PID=$!
./router &
ROUTER_PID=$!

./client set hello world
./client get hello
./client delete hello

kill $CLIENT_PID
kill $ROUTER_PID
wait