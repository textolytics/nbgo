/* One caveat, this routes to a single destination.  To route to many, we'd essentially need to have a
 * map of ids -> dealers, from which we selected.  We'd then put them all in the poll.  The backward trip
 * would be more or less the same (picking the address off the end)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <czmq.h>
#include <zmq.h>

int main() {
  zctx_t *ctx = zctx_new();
  void *dealer = zsocket_new(ctx, ZMQ_DEALER);
  void *router = zsocket_new(ctx, ZMQ_ROUTER);

  zsocket_bind(router, "tcp://*:2222");
  zsocket_connect(dealer, "tcp://localhost:1111");
  zmq_pollitem_t items[2];
  items[0].socket = router;
  items[0].events = ZMQ_POLLIN;
  items[1].socket = dealer;
  items[1].events = ZMQ_POLLIN;
  while (zmq_poll(items, 2, -1) > 0) {
    if (items[0].revents & ZMQ_POLLIN) {
      zmsg_t *req = zmsg_recv(router);
      zframe_t *address = zmsg_pop(req);
      zmsg_add(req, address);
      zmsg_send(&req, dealer);
    }
    if (items[0].revents & ZMQ_POLLIN) {
      zmsg_t *reply = zmsg_recv(dealer);
      zframe_t *address = zmsg_last(reply);
      zmsg_remove(reply, address);
      zmsg_push(reply, address);
      zmsg_send(&reply, router);
    }
  }

  zsocket_destroy(ctx, dealer);
  zsocket_destroy(ctx, router);
  zctx_destroy(&ctx);

  return 0;
}