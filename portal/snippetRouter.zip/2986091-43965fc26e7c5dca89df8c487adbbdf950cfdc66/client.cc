#include <stdio.h>
#include <stdlib.h>
#include <czmq.h>
#include <zmq.h>

int main(int argc, char *argv[]) {
  zctx_t *ctx = zctx_new();
  void *dealer = zsocket_new(ctx, ZMQ_DEALER);

  zsocket_connect(dealer, "tcp://localhost:%d", 2222);

  zmsg_t *msg = zmsg_new();
  for (int i = 1; i < argc; i++) {
    zmsg_addstr(msg, "%s", argv[i]);
  }
  zmsg_send(&msg, dealer);
  msg = zmsg_recv(dealer);
  if (msg != NULL) {
    while (zmsg_size(msg) > 0) {
      char *s = zmsg_popstr(msg);
      printf("%s\n", s);
      free(s);
    }
    zmsg_destroy(&msg);
  } else {
    printf("failed\n");
  }

  zsocket_destroy(ctx, dealer);
  zctx_destroy(&ctx);
  return 0;
}