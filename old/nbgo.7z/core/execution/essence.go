package core

type inbound struct{}

type outbound struct{}
