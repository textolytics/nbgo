package core

type carrierType struct{}
