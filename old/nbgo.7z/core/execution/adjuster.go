package core

type change func()

type component struct{}
