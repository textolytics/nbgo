package core

type data struct{}

type schema struct{}

type dataWarehouse interface {

	// net
	// db
	// batch file
	// ems
	// memory

}

// phase conversion
