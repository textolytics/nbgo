package core

type consumer interface{}

type transformer interface{}

type distributor interface{}
