package core

type downstream interface{}

type upstream interface{}

type gatewayClient func()
