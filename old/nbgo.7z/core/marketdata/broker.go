package marketdata

type carrier struct{}
