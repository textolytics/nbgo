package marketdata

type Event struct{}
