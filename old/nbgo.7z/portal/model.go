package portal

type PortalEvent struct{}

// type PortalArrival struct {
// 	// SourceTimestamp      timestamppb.Timestamp
// 	Source      *Portal
// 	Destination *Portal
// 	// DestinationTimestamp timestamppb.Timestamp
// 	Context PortalEvent
// }

// type PortalDeparture struct {
// 	// SourceTimestamp      timestamppb.Timestamp
// 	Source      *Portal
// 	Destination *Portal
// 	// DestinationTimestamp timestamppb.Timestamp
// 	Context PortalEvent
// }
