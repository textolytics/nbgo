package portal

type change struct{}

type approach func()

type component struct{}
