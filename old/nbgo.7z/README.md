# Phase III

GPU EMS


 smtp-relay.gmail.com                         │ │
                             │ │Port     587                                          │ │
                             │ │Login    nabla.advisory@gmail.com                     │ │
                             │ │Password Cap1talzeal0t    